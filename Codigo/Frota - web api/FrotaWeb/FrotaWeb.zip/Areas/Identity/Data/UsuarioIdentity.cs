using Microsoft.AspNetCore.Identity;

namespace FrotaWeb.Areas.Identity.Data;

// Add profile data for application users by adding properties to the UsuarioIdentity class
public class UsuarioIdentity : IdentityUser
{
}

