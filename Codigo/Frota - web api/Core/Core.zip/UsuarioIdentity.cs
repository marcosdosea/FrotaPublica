﻿using Microsoft.AspNetCore.Identity;

namespace Core;

public class UsuarioIdentity : IdentityUser
{
}
