# Widgets Reutilizáveis

Esta pasta contém widgets reutilizáveis que podem ser utilizados em diferentes partes do aplicativo para manter consistência visual e reduzir duplicação de código.

## ActionCard

O `ActionCard` é um widget reutilizável para cards de ação que podem ser usados em listas horizontais.

### Propriedades

- `icon` (IconData, obrigatório): Ícone do card
- `title` (String, obrigatório): Título do card
- `onTap` (VoidCallback?, opcional): Função chamada quando o card é tocado
- `iconColor` (Color, opcional): Cor do ícone (padrão: `Color(0xFF0066CC)`)
- `iconBgColor` (Color?, opcional): Cor de fundo do ícone
- `hasNotification` (bool, opcional): Se o card tem notificação (padrão: false)
- `isCompleted` (bool, opcional): Se o card está completado (padrão: false)
- `isDisabled` (bool, opcional): Se o card está desabilitado (padrão: false)
- `isDark` (bool, obrigatório): Se o tema atual é escuro

### Exemplo de Uso

```dart
import '../utils/widgets/action_card.dart';

// Em um ListView horizontal
ActionCard(
  icon: Icons.local_gas_station,
  title: 'Registrar\nAbastecimento',
  onTap: () {
    // Navegação ou ação
  },
  isDark: Theme.of(context).brightness == Brightness.dark,
),

// Com notificação
ActionCard(
  icon: Icons.checklist,
  title: 'Realizar Vistoria',
  onTap: () {
    // Navegação ou ação
  },
  hasNotification: true,
  isDark: Theme.of(context).brightness == Brightness.dark,
),

// Com estado de completado
ActionCard(
  icon: Icons.checklist,
  title: 'Realizar Vistoria',
  onTap: () {
    // Navegação ou ação
  },
  isCompleted: true,
  isDark: Theme.of(context).brightness == Brightness.dark,
),

// Desabilitado
ActionCard(
  icon: Icons.cancel,
  title: 'Finalizar Percurso',
  onTap: () {
    // Navegação ou ação
  },
  isDisabled: true,
  iconColor: Colors.red,
  iconBgColor: Colors.red.withOpacity(0.1),
  isDark: Theme.of(context).brightness == Brightness.dark,
),
```

### Características

- **Design Responsivo**: Adapta-se automaticamente ao tema claro/escuro
- **Estados Visuais**: Suporta estados de notificação, completado e desabilitado
- **Animações**: Inclui sombras e gradientes para melhor experiência visual
- **Acessibilidade**: Suporta toque e feedback visual
- **Customização**: Permite personalização de cores e ícones

### Telas que Utilizam

- `driver_home_screen.dart`: Cards de ações principais
- `map_screen.dart`: Cards de ações no mapa

### Manutenção

Para adicionar novos widgets reutilizáveis:

1. Crie o arquivo na pasta `utils/widgets/`
2. Siga o padrão de nomenclatura `snake_case` para o arquivo
3. Use `PascalCase` para o nome da classe
4. Adicione documentação clara das propriedades
5. Inclua exemplos de uso
6. Teste em diferentes contextos (tema claro/escuro, diferentes tamanhos de tela) 